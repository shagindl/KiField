=======
Credits
=======

Development Lead
----------------

* XESS Corp. <info@xess.com>

Contributors
------------

Kaspar Emanuel: https://github.com/kasbah
