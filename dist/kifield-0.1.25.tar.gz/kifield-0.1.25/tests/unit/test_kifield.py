#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
test_kifield
----------------------------------

Tests for `kifield` module.
"""

import unittest

from kifield import kifield

class TestKifield(unittest.TestCase):

    def setUp(self):
        pass

    def test_something(self):
        pass

    def tearDown(self):
        pass

if __name__ == '__main__':
    unittest.main()
