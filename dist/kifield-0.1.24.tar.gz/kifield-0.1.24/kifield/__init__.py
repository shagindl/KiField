# -*- coding: utf-8 -*-

from .pckg_info import *
